package com.example.demo;

import com.example.demo.entity.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.session.SessionProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RedisCT {

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private ValueOperations<String,Object> valueOperations;

    @Autowired
    private SetOperations<String,Object> setOperations;

    @Test
    public void testvalueOption() throws Exception{
        User user = new User();
        user.setAddress("xiamen");
        user.setAge(23);
        user.setName("sudongzhao");
        valueOperations.set("per",user);
    }

}
